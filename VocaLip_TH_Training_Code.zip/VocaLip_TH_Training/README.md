# VocaLip-TH Training Code
Run notebooks 00→17.

This package includes acquisition, subtitle/vocabulary inventory, QC, stable mouth-ROI design, SSL/CTC architecture contracts, tests, report graphs, token confusion matrix, and deployment export.

Important: notebooks 06–08 and 13–15 intentionally require REAL prepared data. They do not fabricate samples or pretend a complete SSL/CTC training run exists. Before CTC training you must populate supervised_manifest.csv with video_path, speaker_id, transcript and build the actual mouth cache/dataloader.

Online video should only be downloaded/used where you have authorization/permission.
