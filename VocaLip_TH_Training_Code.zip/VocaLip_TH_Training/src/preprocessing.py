import cv2, numpy as np
def stable_square_crop(rgb,cx,cy,size,out_size=112):
    h,w=rgb.shape[:2]; q=size/2
    x1,y1,x2,y2=map(int,[cx-q,cy-q,cx+q,cy+q])
    L,T,R,B=max(0,-x1),max(0,-y1),max(0,x2-w),max(0,y2-h)
    if any((L,T,R,B)):
        rgb=cv2.copyMakeBorder(rgb,T,B,L,R,cv2.BORDER_REPLICATE); x1+=L;x2+=L;y1+=T;y2+=T
    return cv2.resize(rgb[y1:y2,x1:x2],(out_size,out_size),interpolation=cv2.INTER_AREA)
