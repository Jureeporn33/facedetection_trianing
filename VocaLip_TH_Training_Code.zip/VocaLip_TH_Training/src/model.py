import torch
import torch.nn as nn
class VisualEncoder(nn.Module):
    def __init__(self,dim=256):
        super().__init__()
        self.net=nn.Sequential(nn.Conv2d(3,32,5,2,2),nn.BatchNorm2d(32),nn.ReLU(),
            nn.Conv2d(32,64,3,2,1),nn.BatchNorm2d(64),nn.ReLU(),
            nn.Conv2d(64,128,3,2,1),nn.BatchNorm2d(128),nn.ReLU(),
            nn.Conv2d(128,256,3,2,1),nn.BatchNorm2d(256),nn.ReLU(),nn.AdaptiveAvgPool2d(1))
        self.proj=nn.Linear(256,dim)
    def forward(self,x):
        b,t,c,h,w=x.shape
        z=self.net(x.reshape(b*t,c,h,w)).flatten(1)
        return self.proj(z).reshape(b,t,-1)
class VocaLipCTC(nn.Module):
    def __init__(self,vocab_size,dim=256,hidden=256,layers=2):
        super().__init__(); self.encoder=VisualEncoder(dim)
        self.temporal=nn.GRU(dim,hidden,layers,batch_first=True,bidirectional=True,dropout=.2)
        self.head=nn.Linear(hidden*2,vocab_size)
    def forward(self,x):
        z=self.encoder(x); z,_=self.temporal(z); return self.head(z)
