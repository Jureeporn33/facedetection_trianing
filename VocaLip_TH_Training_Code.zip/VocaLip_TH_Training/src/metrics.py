def lev(a,b):
    p=list(range(len(b)+1))
    for i,x in enumerate(a,1):
        c=[i]
        for j,y in enumerate(b,1): c.append(min(c[-1]+1,p[j]+1,p[j-1]+(x!=y)))
        p=c
    return p[-1]
def cer(r,h): return lev(list(r),list(h))/max(1,len(r))
def wer(r,h): return lev(r.split(),h.split())/max(1,len(r.split()))
