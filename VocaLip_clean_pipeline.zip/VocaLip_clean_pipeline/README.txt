# VocaLip Clean Pipeline

Run order:
0. 00_environment_check.ipynb
1. 01_dataset_preparation.ipynb
2. 02_mouth_preprocessing.ipynb
3. 03_dataset_split.ipynb
4. 04_model_definition.ipynb
5. 05_training.ipynb
6. 06_evaluation.ipynb
7. 07_temporal_diagnostic.ipynb
8. 08_deployment_export.ipynb

Important:
- Change PROJECT_ROOT in every notebook to the new machine path.
- Put videos under data/raw_videos/<word>/*.mp4
- Put face_landmarker.task under assets/
- Training/deployment preprocessing must remain identical.
- Current split notebook is in-domain stratified, NOT speaker-disjoint.
